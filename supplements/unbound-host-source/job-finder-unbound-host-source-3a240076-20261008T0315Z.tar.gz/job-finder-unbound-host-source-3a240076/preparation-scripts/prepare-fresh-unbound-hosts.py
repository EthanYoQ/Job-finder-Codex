#!/usr/bin/env python3
"""Prepare exact-literal r4 rebinding in fresh absent hosts/owner directories.
Creates unbound source/templates only; never activation.json, control-base.json,
registration, source HTTP, SQL dispatch, launch or historical run state.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,re,shutil,subprocess
p=argparse.ArgumentParser();p.add_argument('--input',required=True);a=p.parse_args()
HERE=Path(__file__).resolve().parent;R=HERE.parent.parent;PRODUCER=R/'producer'
S=R.parent/'job-finder-safe-recovery-20261007T2250Z/hansoh-fosun-c51-r4';P=S/'payload'
O='owner-adaptations/hansoh-fosun-c51-r4-20261007T2149Z';NODE=R/'node-v22.23.3-linux-x64/bin/node'
sha=lambda b:hashlib.sha256(b).hexdigest()
def write_new(path,data):
 path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
 with path.open('xb') as f:f.write(data)
 os.chmod(path,0o600)
def run(args,env=None,cwd=None):
 r=subprocess.run(list(map(str,args)),cwd=cwd,capture_output=True,text=True,env=env,check=True);return r.stdout
for dest in [R/'hosts',R/'owner-adaptations',HERE/'prepared-host-staging',HERE/'FRESH_UNBOUND_HOST_MANIFEST.json']:
 assert not dest.exists() and not dest.is_symlink(),f'NO_OVERWRITE:{dest}'
for q in [R,PRODUCER,NODE,HERE,Path(a.input).absolute()]:
 for v in [q,*q.parents]:assert not v.is_symlink(),f'NO_SYMLINK:{v}'
inputBytes=Path(a.input).read_bytes();data=json.loads(inputBytes)
assert set(data)=={'schemaVersion','build','candidate','gitAuthorityDecision'}
assert data['schemaVersion']==1 and data['gitAuthorityDecision']=='A_HONEST_DERIVED_SOURCE_COMMIT'
build=data['build'];candidate=data['candidate']
assert set(candidate)=={'id','goalId','version'} and candidate['goalId']=='jobfinder-portable-required-40'
assert re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,99}',candidate['id'])
assert candidate['id']!='dot-cloud-delta-proxy-28402a29-20261007'
assert type(candidate['version']) is int and candidate['version']>=51
assert candidate['version']!=51,'Original goal/version51 is already registered; no tuple reuse'
assert build==json.loads((PRODUCER/'build-identity.json').read_text())
oldBuild=json.loads((P/'hosts/hansoh/host/control-base.template.json').read_text())['build']
assert build['commitSha']!=oldBuild['commitSha'],'DERIVED_COMMIT_REQUIRED'
assert run(['git','rev-parse','HEAD'],cwd=PRODUCER).strip()==build['commitSha']
assert run(['git','status','--porcelain'],cwd=PRODUCER).strip()==''
verify=run(['python3',S/'verify-snapshot.py']);assert json.loads(verify)['status']=='SOURCE_BYTES_VERIFIED'
env=dict(os.environ);env.pop('NODE_OPTIONS',None);env.pop('DATABASE_URL',None);env['PATH']=str(NODE.parent)+':'+env.get('PATH','');env['TSX_DISABLE_CACHE']='1';env['NODE_DISABLE_COMPILE_CACHE']='1'
loader=PRODUCER/'node_modules/tsx/dist/loader.mjs';guard=R/'verification/offline-network-guard.cjs'
actual=json.loads(run([NODE,'--require',guard,'--import',loader,'--input-type=module','-e',"import {createBuildIdentity} from './src/readiness/buildIdentity.ts';console.log(JSON.stringify(createBuildIdentity(process.cwd(),process.argv[1])));",build['commitSha']],env,PRODUCER))
assert actual==build,'FRESH_CANONICAL_BUILD_REQUIRED'
profile=json.loads(run([NODE,'--require',guard,'--import',loader,'scripts/verify-node-runtime-profile.ts'],env,PRODUCER))
oldRoot=json.loads((P/O/'baseline-manifest.json').read_text())['runtimeRoot'];oldNode=oldRoot+'/runtime/node-v22.23.3-linux-x64/bin/node'
oldId='dot-cloud-delta-proxy-28402a29-20261007'
rewrites=[(oldNode,str(NODE)),(oldRoot+'/runtime/node-v22.23.3-linux-x64/bin',str(NODE.parent)),(oldRoot,str(R)),(oldId,candidate['id'])]+[(v,build[k]) for k,v in oldBuild.items() if isinstance(v,str)]
def adapt(text):
 for before,after in rewrites:text=text.replace(before,after)
 text=re.sub(r'(\.version\s*!==\s*)51\b',lambda m:m.group(1)+str(candidate['version']),text)
 text=text.replace('version:z.literal(51)','version:z.literal('+str(candidate['version'])+')')
 return text
stage=HERE/'prepared-host-staging';stage.mkdir(mode=0o700)
changes=[];skipped={'context-read.sql.template','context-template-proof.json','preload-owner.exec.js','publish-reviewed-and-monitor.exec.js'}
for f in sorted(P.rglob('*')):
 if not f.is_file():continue
 rel=f.relative_to(P)
 if f.name in skipped:continue
 before=f.read_bytes();after=adapt(before.decode()).encode();write_new(stage/rel,after)
 changes.append({'path':str(rel),'beforeSha256':sha(before),'afterInitialAdaptationSha256':sha(after),'changed':before!=after})
# Existing reviewed context generator emits source-specific placeholder contexts.
generator=R/'verification/hansoh-fosun-c51-r4/generate-context.mts'
assert generator.read_bytes()==(S/'generate-context.mts').read_bytes()
compiler=[]
for key,sourceId in [('hansoh','source-hansoh-social'),('fosun','source-fosun-pharma-social')]:
 e={**env,'JOBFINDER_CLOUD_SOURCE_ID':sourceId}
 compiler.append(json.loads(run([NODE,'--require',guard,'--import',loader,generator,key,stage],e,PRODUCER)))
 h=stage/'hosts'/key/'host'
 assert json.loads((h/'control-base.template.json').read_text())['candidate'] is None
 assert json.loads((h/'owner-binding-input.template.json').read_text())['databaseIdentity'] is None
 assert (h/'runtime/load-host-state.js').read_bytes()==(h/'runtime/load-host-state.unbound.template.js').read_bytes()
 assert (stage/'hosts'/key/'supervision'/f'start-monitor-{key}51-combined.js').read_bytes()==(stage/'hosts'/key/'supervision'/f'start-monitor-{key}51-combined.unbound.template.js').read_bytes()
 # Validate and refresh combined sampler/supervisor/wrapper/inspector byte pins.
 for name in [f'start-monitor-{key}51-combined.js',f'start-monitor-{key}51-combined.unbound.template.js']:
  path=stage/'hosts'/key/'supervision'/name;text=path.read_text()
  for rel in [f'hosts/{key}/supervision/sample_process_tree.py',f'hosts/{key}/supervision/supervise-cancel.mjs',f'hosts/{key}/supervision/inspect-launch-identity.mjs']:
   old=sha((P/rel).read_bytes());new=sha((stage/rel).read_bytes());assert old in text;text=text.replace(old,new)
  wrapper=sha((PRODUCER/'scripts/run-with-http-diagnostics.mjs').read_bytes());assert wrapper in text,'WRAPPER_BYTES_MUST_REMAIN_UNCHANGED'
  path.write_text(text);os.chmod(path,0o600)
# Preserve exact ten-file closure, refreshing paths/byte pins from prepared sources.
m=json.loads((stage/O/'baseline-manifest.json').read_text());assert len(m['files'])==10
for final,row in m['files'].items():
 rel=Path(final).relative_to(R);content=(stage/rel).read_bytes();row.update(sha256=sha(content),bytes=len(content))
(stage/O/'baseline-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
# All source bindings are checked before creating either final fresh directory.
for f in stage.rglob('*'):
 if f.is_file():
  text=f.read_text();assert oldRoot not in text and oldId not in text and oldBuild['contentSha256'] not in text,f
for forbidden in ['activation.json','activation.prepared.json','control-base.json','context-read.sql','owner-binding-input.json']:
 assert not list(stage.rglob(forbidden)),forbidden
assert not (R/'hosts').exists() and not (R/'owner-adaptations').exists()
os.rename(stage/'hosts',R/'hosts');os.rename(stage/'owner-adaptations',R/'owner-adaptations')
# Run the original reviewed generator at its final source directory so its path pin is exact.
fragments=json.loads(run(['python3',R/O/'build-fragments.py'],env))
files=[]
for root in [R/'hosts',R/'owner-adaptations']:
 for f in sorted(root.rglob('*')):
  if f.is_file():
   os.chmod(f,0o600);b=f.read_bytes();files.append({'path':str(f.relative_to(R)),'bytes':len(b),'sha256':sha(b)})
assert len(files)==69
assert run(['git','status','--porcelain'],cwd=PRODUCER).strip()==''
assert json.loads(run(['python3',S/'verify-snapshot.py']))['status']=='SOURCE_BYTES_VERIFIED'
receipt={'schemaVersion':1,'classification':'FRESH_DERIVED_R4_UNBOUND_SOURCE_PREPARATION','generatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(R),'inputPath':str(Path(a.input).absolute()),'inputSha256':sha(inputBytes),'originalC51Commit':oldBuild['commitSha'],'derivedProducerCommit':build['commitSha'],'build':build,'candidateIntentOnly':candidate,'databaseIdentity':None,'nodeRuntime':profile,'sourceChanges':changes,'contextCompilers':compiler,'fragmentPins':fragments,'files':files,'activationPresent':False,'liveControlPresent':False,'registrationPerformed':False,'sqlExecuted':False,'captureStarted':False,'originalSourceModified':False,'excludedOriginalPathsExported':False,'unchangedRules':{'dueMs':43200000,'wrapperDeadlineMs':1800000,'heapMiB':384,'httpTimeoutMs':45000,'serialPublishing':True,'originalUnknownUnchanged':True}}
write_new(HERE/'FRESH_UNBOUND_HOST_MANIFEST.json',(json.dumps(receipt,indent=2)+'\n').encode())
print(json.dumps({'status':'UNBOUND_SOURCE_PREPARED','files':len(files),'manifest':str(HERE/'FRESH_UNBOUND_HOST_MANIFEST.json'),'activation':False,'capture':False}))
