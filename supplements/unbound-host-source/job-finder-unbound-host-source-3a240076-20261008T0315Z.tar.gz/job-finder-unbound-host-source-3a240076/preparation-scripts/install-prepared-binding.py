#!/usr/bin/env python3
"""Future authorized local installation only. Defaults to check-only.
--activate explicitly installs compiler-prepared files, replaces only byte-matched
unbound entrypoints, and creates activation.json LAST. Never launches or executes SQL.
If interrupted, stop and reconcile actual files; do not blindly rerun.
"""
from pathlib import Path
import argparse,hashlib,json,os
p=argparse.ArgumentParser();p.add_argument('--prepared',required=True);p.add_argument('--activate',action='store_true');a=p.parse_args()
H=Path(__file__).resolve().parent;R=H.parent.parent;prepared=Path(a.prepared).absolute();manifest=json.loads((prepared/'PREPARED_BINDING_MANIFEST.json').read_text());expected=json.loads((H/'FRESH_HOST_PREPARATION_INPUT.json').read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
assert manifest['classification']=='OWNER_BINDING_PREPARED_NOT_ACTIVATED';assert manifest['candidate']==expected['candidate'];assert manifest['build']==expected['build']==json.loads((R/'producer/build-identity.json').read_text())
host=Path(manifest['host']);key=host.parent.name;assert key in ['hansoh','fosun'] and host==R/'hosts'/key/'host';base=host.parent
frozen=json.loads((H/'FRESH_UNBOUND_HOST_MANIFEST.json').read_text())
for row in frozen['files']:
 if row['path'].startswith('hosts/'+key+'/') or row['path'].startswith('owner-adaptations/'):
  current=R/row['path'];assert current.is_file() and not current.is_symlink()
  b=current.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],'FROZEN_UNBOUND_SOURCE_CHANGED:'+row['path']
for path in [prepared,host]:
 for parent in [path,*path.parents]:assert not parent.is_symlink()
for row in manifest['files']:
 path=Path(row['path']);assert not path.is_absolute() and '..' not in path.parts
 b=(prepared/path).read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256']
activation=json.loads((prepared/'host/activation.prepared.json').read_text());assert activation['status']=='PREPARED_NOT_ACTIVATED';assert activation['candidate']==expected['candidate'] and activation['build']==expected['build']
assert sha(Path(activation['registrationReadbackPath']).read_bytes())==activation['registrationReadbackSha256']
assert sha((prepared/'owner-binding-input.json').read_bytes())==activation['ownerInputSha256']
newNames=['host/control-base.json','host/context-read.sql'];replaceNames=['host/runtime/load-host-state.js',f'supervision/start-monitor-{key}51-combined.js']
for name in newNames:assert not (base/name).exists(),f'UNEXPECTED_EXISTING_BINDING:{name}'
assert not (host/'activation.json').exists(),'ALREADY_BOUND_OR_UNKNOWN_INSTALL'
for name in replaceNames:
 target=base/name;template=target.with_name(target.stem+'.unbound.template'+target.suffix)
 assert target.read_bytes()==template.read_bytes(),f'NOT_UNBOUND:{target}'
assert sha((prepared/'host/runtime/load-host-state.js').read_bytes())==activation['loaderSha256']
assert sha((prepared/f'supervision/start-monitor-{key}51-combined.js').read_bytes())==activation['starterSha256']
assert sha((prepared/'host/context-read.sql').read_bytes())==activation['contextReadSha256']
if not a.activate:
 print(json.dumps({'status':'CHECKED_NO_CHANGES','host':str(host),'candidate':expected['candidate'],'activation':False}));raise SystemExit(0)
def exclusive(path,content):
 with path.open('xb') as f:f.write(content);f.flush();os.fsync(f.fileno())
 path.chmod(0o600)
for name in newNames:exclusive(base/name,(prepared/name).read_bytes())
for name in replaceNames:
 target=base/name;template=target.with_name(target.stem+'.unbound.template'+target.suffix)
 assert target.read_bytes()==template.read_bytes(),f'CONCURRENT_SOURCE_CHANGE:{target}'
 temp=target.with_name(target.name+'.prepared-install.tmp');exclusive(temp,(prepared/name).read_bytes());os.replace(temp,target)
activation['status']='REGISTERED_VERIFIED'
exclusive(host/'activation.json',(json.dumps(activation,indent=2)+'\n').encode())
for name in newNames+replaceNames:assert (base/name).read_bytes()==(prepared/name).read_bytes()
print(json.dumps({'status':'REGISTERED_VERIFIED_BINDING_INSTALLED','host':str(host),'candidate':expected['candidate'],'activationSha256':sha((host/'activation.json').read_bytes()),'sqlExecuted':False,'captureStarted':False,'next':'Run inspect-host-binding.mts before loading owner session code.'}))
