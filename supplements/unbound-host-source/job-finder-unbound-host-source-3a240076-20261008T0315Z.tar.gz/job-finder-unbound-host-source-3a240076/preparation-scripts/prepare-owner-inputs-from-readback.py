#!/usr/bin/env python3
"""Derive owner input files from an already obtained actual registration readback.
No SQL, installation, activation or launch. Existing prepare-owner-binding.mts
must still verify the full official row before any prepared output is accepted.
"""
from pathlib import Path
import argparse,hashlib,json,re
p=argparse.ArgumentParser();p.add_argument('--readback',required=True);p.add_argument('--destination',required=True);a=p.parse_args()
H=Path(__file__).resolve().parent;R=H.parent.parent
v=json.loads((H/'FRESH_HOST_PREPARATION_INPUT.json').read_text());build=json.loads((R/'producer/build-identity.json').read_text());assert build==v['build']
readbackPath=Path(a.readback).absolute();raw=readbackPath.read_bytes();r=json.loads(raw);row=r.get('candidateRow',r.get('row'));assert isinstance(row,dict),'ACTUAL_NORMALIZED_REGISTRATION_ROW_REQUIRED'
assert {k:row[k] for k in ['id','goalId','version']}==v['candidate'],'EXACT_PREPARED_CANDIDATE_REQUIRED'
assert row['commitSha']==build['commitSha'] and row['status']=='BUILDING'
db={k:row[k] for k in ['migrationVersion','schemaHash','dbSnapshotHash']};assert db['migrationVersion']=='20261006172300_job_projection_delta_contract'
for k in ['schemaHash','dbSnapshotHash']:assert re.fullmatch('[a-f0-9]{64}',db[k]) and db[k]!='0'*64
out=Path(a.destination).absolute();assert not out.exists()
for path in [readbackPath,out]:
 for ancestor in [path,*path.parents]:assert not ancestor.is_symlink()
contents={}
for key in ['hansoh','fosun']:
 cfg=json.loads((R/'hosts'/key/'host/host-config.json').read_text())
 owner={'schemaVersion':1,'build':build,'candidate':v['candidate'],'databaseIdentity':db,'minimumCandidateVersion':51,'sourceId':cfg['sourceId'],'sourceConfigSha256':cfg['sourceConfigSha256']}
 contents[f'{key}-owner-binding-input.json']=json.dumps(owner,indent=2)+'\n'
out.mkdir(mode=0o700)
for name,text in contents.items():
 with (out/name).open('x') as f:f.write(text)
 (out/name).chmod(0o600)
receipt={'classification':'OWNER_INPUTS_ONLY_REGISTRATION_NOT_PERFORMED','readbackPath':str(readbackPath),'readbackSha256':hashlib.sha256(raw).hexdigest(),'candidate':v['candidate'],'databaseIdentity':db,'build':build,'activation':False}
with (out/'OWNER_INPUT_RECEIPT.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps({'ownerInputs':str(out),'activation':False,'next':'Run each existing prepare-owner-binding.mts with the same exact readback file.'}))
