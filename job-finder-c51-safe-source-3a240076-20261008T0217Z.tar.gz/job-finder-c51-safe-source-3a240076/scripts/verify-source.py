#!/usr/bin/env python3
"""Verify exact source bytes and Git identity; never install, connect or deploy."""
from pathlib import Path
import argparse,hashlib,json,subprocess,stat
parser=argparse.ArgumentParser();parser.add_argument('source_root');args=parser.parse_args()
root=Path(args.source_root).resolve();pkg=Path(__file__).resolve().parents[1]
m=json.load(open(pkg/'SOURCE_MANIFEST.json')); expected={f['path'] for f in m['files']}
for f in m['files']:
 p=root/f['path']; assert p.is_file() and not p.is_symlink(),f['path']
 for parent in p.parents:
  if parent==root:break
  assert not parent.is_symlink(),str(parent)
 b=p.read_bytes();assert len(b)==f['bytes'] and hashlib.sha256(b).hexdigest()==f['sha256'],f['path']
 assert bool(p.stat().st_mode&0o111)==(f['gitMode']=='100755'),f['path']+' mode'
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert blob==f['gitBlob'],f['path']+' git blob'
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file() and '.git' not in p.relative_to(root).parts}
assert actual==expected,{'missing':sorted(expected-actual),'unexpected':sorted(actual-expected)}
if (root/'.git').is_dir():
 def git(*args):return subprocess.check_output(['git','-C',str(root),*args],text=True).strip()
 assert git('rev-parse','HEAD')==m['commit'];assert git('rev-parse','HEAD^{tree}')==m['tree']
 assert git('rev-list','--count','HEAD')=='1';assert git('status','--porcelain')==''
print(json.dumps({'status':'PASS','files':len(expected),'bytes':m['totalBytes'],'commit':m['commit'],'tree':m['tree']}))
