// Fixed read-only preflight provenance; prior dbSnapshotHash is a schema-only artifact, not a new backup.
export const CLOUD_PILOT_SQL45 = {
  "checkedAt": "2026-10-02T03:58:26.336279+00:00",
  "currentCandidate": {"id": "portable-0a1f60c-20261002", "goalId": "jobfinder-portable-required-40", "status": "BUILDING", "version": 9, "commitSha": "0a1f60c94a9ccad09cd42806ea920ad88959c8db", "schemaHash": "3d16f384edf00a7b7154e515bc14bd065543f754e332d01e8ddb40723c643872", "dbSnapshotHash": "067462973db6955e562168eeb12d8a039366caa0cea6291ae7fb4a74c08e2d62", "migrationVersion": "20261002020000_gilead_novo_source_policies"},
  "sourceResultGuardMd5": "8fd00ed15932e3101eec3908ac3f33f3",
  migrations: [
  {
    "checksum": "4fdcb581708ac58a54076042daeede1e95e0e30b70ecb44746628628899f9ea5",
    "migrationName": "20260710000000_baseline"
  },
  {
    "checksum": "0b8b060cc62a6cddfac1f0ae2571abd10f05ea20fe218fa1084973443ef4985d",
    "migrationName": "20260710005000_crawl_status_values"
  },
  {
    "checksum": "85cfca6b4430baaf58a168175e18446d428808d69ab14758fcc46ebed377d749",
    "migrationName": "20260710010000_phase1_evidence"
  },
  {
    "checksum": "323a5d11ef6f48dc5b65e4605190e11f21dac7cdf6b8f4d86aaf23d9e4e45551",
    "migrationName": "20260710015000_completeness_pending"
  },
  {
    "checksum": "29af5ebcafa874a829be6a071a0ae7e4c00ffed22e2b1b41acd5799680014998",
    "migrationName": "20260710020000_source_result_state_machine"
  },
  {
    "checksum": "ea4c8416dd62bb7368c9b79b0cdfe2987afa3bcc5e9726c02b482b1c553e978b",
    "migrationName": "20260711050000_task5g_truth_persistence"
  },
  {
    "checksum": "74748a3e48319b6e39aead158e658ed384e54fd874eb8c9f2ea58f6c303dd454",
    "migrationName": "20260711060000_transport_attempt_artifact_immutability"
  },
  {
    "checksum": "046381cc43edf9551e1ebd4629c4add665556ea4d89cc2b9962cd9158df34972",
    "migrationName": "20260711150000_task5h_runtime_truth_closure"
  },
  {
    "checksum": "3152d9cdf10b4d04c1b775546d1127f6d689c21179ec4907b5f77e98e7bf741d",
    "migrationName": "20260711210000_lifecycle_set_evidence_members"
  },
  {
    "checksum": "f7c5bacc9d558cedbbaf332ea384b8d01c635a9f94495e375df752861f2ca4c9",
    "migrationName": "20260711220000_lifecycle_set_cryptographic_closure"
  },
  {
    "checksum": "5eece361b4d5b01f6e867ff28e2081ee1febc499c218d675b09c9331d7bf35bf",
    "migrationName": "20260711230000_parent_lifecycle_projection_gate"
  },
  {
    "checksum": "5ebb0b22c7c14e02de0de0df6e5ec88de1b9e12105b2b7ea064c6532fec93d22",
    "migrationName": "20260711240000_lifecycle_trigger_security_closure"
  },
  {
    "checksum": "a9e02aa75fda3f91831acba4893f6a9c6fb723b0e47b829acfcf29c94a5050df",
    "migrationName": "20260712020000_release_runtime_identity"
  },
  {
    "checksum": "f3b2fec28c76402d95d712a9f07b532fe6368a2e23bb551310fd116aff0fca96",
    "migrationName": "20260713010000_manual_crawl_request_ownership"
  },
  {
    "checksum": "0502883a5386be381be4b93f27a4968b88f7c0cb9cb71f79069eeddff083c09d",
    "migrationName": "20260713020000_privacy_request_retention"
  },
  {
    "checksum": "76ee502c2329ff180e61b0e1ee6081bb2f6a6925baa950b639ef32b72b8789c9",
    "migrationName": "20260713030000_manual_crawl_preview_isolation"
  },
  {
    "checksum": "dc44a8720be3980d8350871a6c7ba39dee6e59897954caed9b1c27dcd4eeceb5",
    "migrationName": "20260713035000_quarantine_legacy_unbound_manual_batches"
  },
  {
    "checksum": "f80a08566fa3d6a891551cf6a2c04c8d4cd04ecf56748527d20c518da711ed17",
    "migrationName": "20260713040000_manual_batch_binding_and_kind_immutability"
  },
  {
    "checksum": "99760a680cf3e8109c06f36e1f3ec09ac6d636c017d2fb7a1edac1a5bc612864",
    "migrationName": "20260713050000_ai_enrichment_persistence"
  },
  {
    "checksum": "9f0d24e3e69c62194212b73028b2ce189da3921120eec28d4019d98cb5008c64",
    "migrationName": "20260714053000_repair_legacy_offline_count_two"
  },
  {
    "checksum": "3ba00cb12be5b70f71b421f010ece0e21d9fd0dda451e8b882a499bd5a3bfb2b",
    "migrationName": "20260715090000_atomic_evidence_commit_scaling"
  },
  {
    "checksum": "3b359a8c7d66128a849b651644bf79598a28394fdb7ec98c22c6cadbf860c220",
    "migrationName": "20260716190000_release_candidate_qualification_threshold"
  },
  {
    "checksum": "aade090681832348f44f8002f9cf64dad79f64db991637a5c39f5d8675d3b54e",
    "migrationName": "20260716210000_release_candidate_promotion_gate"
  },
  {
    "checksum": "c1d858486c56a41ddbc46489ae39a3a221234a33951ddbd96685a18cf393a02f",
    "migrationName": "20260717090000_source_failure_diagnostics"
  },
  {
    "checksum": "57e5d92b5520bce6817dbf067001037e596ae09fdf01d34a47af656aa12b3fc7",
    "migrationName": "20260812231000_a_grade_completeness_certificate"
  },
  {
    "checksum": "c9067ade70b02c5204f988604c273db34a1a94d0c0b4d84fe9d99955b743fb11",
    "migrationName": "20260813002000_trusted_completeness_baseline"
  },
  {
    "checksum": "49d2bbec31985956304c829818ccd3d2b0279dfeef6be88555ce7d224e5c8e69",
    "migrationName": "20260813013000_transport_policy_retry_diagnostics"
  },
  {
    "checksum": "522f1d52846568579dd56896c99d83680e528de525a21424892599a2533a338c",
    "migrationName": "20260824070000_official_network_retry_diagnostics"
  },
  {
    "checksum": "31656155cad70ac5a841b4b022c11c27056d0fa2d2cc7c80e17bea710158d6c6",
    "migrationName": "20260825093000_browser_and_pagination_retry_diagnostics"
  },
  {
    "checksum": "f4af5d9b982e42c55f53d415baac1934568ed2b587b3e27fa186d194d6a2e514",
    "migrationName": "20260825113000_failed_source_diagnostic_evidence"
  },
  {
    "checksum": "6897c9b49f215383954f0c7326574dfd0fb2f6944bfd8bf9a5b6a30b79fc1296",
    "migrationName": "20260902090000_jnj_and_grifols_atomic_persistence"
  },
  {
    "checksum": "8f997add3cf96d44e188f4fdab71e54a7896336e2c09fb9f79e1748d697ac645",
    "migrationName": "20260902093000_grifols_trigger_artifact_binding"
  },
  {
    "checksum": "1d7be8f1fe26e033478694687963a805281af61de6575222ecc40335cd721ad9",
    "migrationName": "20260902094500_a_grade_official_total_dedupe"
  },
  {
    "checksum": "f6ad25e94c6a8971f4545880e20037c6eb3814c130f51c926ea6886568c5f06b",
    "migrationName": "20260902095500_boehringer_verified_ui_exclusions"
  },
  {
    "checksum": "5b8c19c744abe771124f4f0a9e7f985e34693ab05dc7a50da87d77b2bb69ca0c",
    "migrationName": "20260927110000_crawl_coordinator_table_lock"
  },
  {
    "checksum": "17b71a51cb5fd63575e7f04ac9f51fe9af72c85d70dd8badb5430ed259606c4d",
    "migrationName": "20260927120000_p0_launch_cohort_41_companies"
  },
  {
    "checksum": "efabdfad4df69d179a252d12781c320475b1e17e038d918243bc195c2e15b496",
    "migrationName": "20261001120000_portable_source_quality_policy"
  },
  {
    "checksum": "6d8d551d9725348aef46c95ebcae876c82fcd77186495c73f9e8a7c29c2bcbba",
    "migrationName": "20261001151000_portable_loss_position_identity"
  },
  {
    "checksum": "5b4bce23e62c78a198c011a0eba37f80f90fb03b0e9591d888188d9c15d224bf",
    "migrationName": "20261001163000_portable_zero_based_loss_pages"
  },
  {
    "checksum": "d01d1b7099c4de2c05d234a7a22fd7278f5dc3b8c1fd982613bf2b068f4fca50",
    "migrationName": "20261001174000_astellas_pdf_city_policy"
  },
  {
    "checksum": "b26a25ae30ca08a2beeb60ac72238218543296e2c1bb691e8d811c46965bdc82",
    "migrationName": "20261001181500_abbvie_reviewed_row_policy"
  },
  {
    "checksum": "865a0dce5252e52614aef3232822e1f2acd7b42b26b8df629fe470b34e8b1713",
    "migrationName": "20261001233000_verified_date_source_policy"
  },
  {
    "checksum": "9ec3df9622f42d48b8472ee6e3bcd7421b0b0f7f0ae480e81d4ae7041636c791",
    "migrationName": "20261002001500_bms_mainland_geography_policy"
  },
  {
    "checksum": "35607b7bf3fd71424144c5958a8dfaedbca2bcfe69a63d55b43449f964d69774",
    "migrationName": "20261002011500_city_pending_source_policies"
  },
  {
    "checksum": "fd24e0f031f9a34cb8ca1ef7c57703795735ddc386e5c0c62a8e3d175b73f18c",
    "migrationName": "20261002020000_gilead_novo_source_policies"
  },
  {
    "checksum": "d0bc0f9092560bad7d0f77fde63b0df2db1cbc512f3babaf3bdd3328291c834d",
    "migrationName": "20261002093322_novo_native_application_policy"
  },
  {
    "checksum": "96bb2c79d1bc4cdcaeeddb1e994b826cd7287f2de3654807c64aea3b2f8f214e",
    "migrationName": "20261002101515_organon_source_policy"
  },
  {
    "checksum": "5b3c8bc039960433709fc7cd1c9d66b6d939c7a7068c00d4b304d4b4ea5e17ac",
    "migrationName": "20261003055000_jnj_dom_evidence_admission"
  }
],
  databaseIdentity: {"migrationVersion": "20261003055000_jnj_dom_evidence_admission", "schemaHash": "f1bae6bd06dd70bccdc9066b7394b16ef3ad71372ebcd64e49f0535af3405a59", "dbSnapshotHash": "6b03926be321dc6dec6d2969c0bc4eab64544c567d2ac065911011becd33f42e"}
} as const;
