import { PortableSearchRequestSchema } from "../domain/search";
import { isCityPendingJob, matchesPortableSearchCity } from "../domain/jobLocation";
import type { PortablePublicSnapshot } from "../db/portablePublicSnapshotRepository";
import type { DatabaseSearchResult } from "./jobSearchService";
import type { CoverageRequest, CoverageResult, CoverageCompany } from "./coverageService";
import { candidateCompanies } from "../data/companyRegistry";

// Scope labels describe the reviewed entry, never a live count or publication
// decision. Counts and visibility still come only from the verified snapshot.
function sourceScopeNote(sourceIds: readonly string[], snapshot: PortablePublicSnapshot): { sourceScopeNote?: string } {
  const notes: Record<string, string> = {
    "source-cspc-social": "石药官方社会招聘频道（人工 D36 指定入口）；仅覆盖该频道，不代表集团及子公司全量。",
    "source-servier-china-social": "施维雅中国 Moka 社会招聘门户（47734）；门户职位总量与已确认中国工作地的职位数量分开核验，未披露工作地的职位保持未知。"
  };
  const servier = snapshot.sources.find(source => source.sourceId === "source-servier-china-social" && source.state === "PUBLISHING")?.sourceScopeSummary;
  if (servier) notes["source-servier-china-social"] = `施维雅中国 Moka 社会招聘门户（47734）：门户职位 ${servier.portalJobCount} 个，明确中国工作地 ${servier.verifiedChinaJobCount} 个，国家待核 ${servier.unknownCountryJobCount} 个（官方标记在招，未计入中国职位）；仅覆盖此门户。`;
  const note = sourceIds.flatMap(id => notes[id] ? [notes[id]] : []).join(" ");
  return note ? { sourceScopeNote: note } : {};
}

export interface PortableCoverageSummary {requiredCompanyCount:number;publishingCompanyCount:number;excludedCompanyCount:number;degradedCompanyCount:number}
export function portableCoverageSummary(snapshot:PortablePublicSnapshot):PortableCoverageSummary {
  return {requiredCompanyCount:snapshot.coverage.requiredCompanyCount,
    publishingCompanyCount:snapshot.companies.filter(c=>c.required&&c.publishingSourceIds.length>0).length,
    excludedCompanyCount:snapshot.coverage.excludedCompanyCount,
    degradedCompanyCount:snapshot.companies.filter(c=>c.required&&c.health==="DEGRADED").length};
}
export interface PublishedJobSummary {
  /** All required, currently publishing jobs in the verified snapshot, before search filters. */
  totalJobs: number;
  cityPendingJobs: number;
}

/** Filter only the reader's already verified, membership-bound projection. Never
 * re-query mutable Job flags or fall back to legacy rows when the snapshot is empty. */
export function searchPortableSnapshot(request:unknown,snapshot:PortablePublicSnapshot):DatabaseSearchResult & {coverageSummary:PortableCoverageSummary;publishedJobSummary:PublishedJobSummary} {
  const q=PortableSearchRequestSchema.parse(request),keyword=q.keyword?.toLocaleLowerCase("zh-CN")??"";
  const date=(s:string|null)=>s===null?Number.NEGATIVE_INFINITY:Date.parse(s);
  const publishedCompanies=snapshot.companies.filter(c=>c.required&&c.publishingSourceIds.length>0);
  const publishedJobs=publishedCompanies.flatMap(c=>c.jobs);
  const publishedJobSummary={totalJobs:publishedJobs.length,cityPendingJobs:publishedJobs.filter(isCityPendingJob).length};
  const companies=publishedCompanies.filter(c=>!q.companyIds.length||q.companyIds.includes(c.id)).map(c=>({
    id:c.id,companyName:c.companyName,pinyin:c.pinyin,...sourceScopeNote(c.publishingSourceIds,snapshot),jobs:c.jobs.filter(j=>
      matchesPortableSearchCity(j,q.city)&&
      (!q.categories.length||q.categories.includes(j.category))&&(!q.newWithinDays||j.isNew)&&
      (!keyword||[j.title,j.officialTitle,c.companyName,c.pinyin].some(text=>text.toLocaleLowerCase("zh-CN").includes(keyword))))
      .map(j=>({...j,cityPending:isCityPendingJob(j)}))
      .sort((a,b)=>(date(b.officialPublishedAt)-date(a.officialPublishedAt)||0)||a.title.localeCompare(b.title)||a.id.localeCompare(b.id))
  })).filter(c=>c.jobs.length>0);
  companies.sort((a,b)=>{
    if(q.sort==="MATCHING_JOB_COUNT_DESC"&&a.jobs.length!==b.jobs.length)return b.jobs.length-a.jobs.length;
    if(q.sort==="LATEST_POSTED"){const delta=date(b.jobs[0]!.officialPublishedAt)-date(a.jobs[0]!.officialPublishedAt);if(delta&&!Number.isNaN(delta))return delta;}
    return a.pinyin.localeCompare(b.pinyin)||a.id.localeCompare(b.id);
  });
  return {companies,totalJobs:companies.reduce((n,c)=>n+c.jobs.length,0),lastUpdatedAt:snapshot.lastUpdatedAt,coverageSummary:portableCoverageSummary(snapshot),publishedJobSummary};
}
export function coverageFromPortableSnapshot(request:CoverageRequest,snapshot:PortablePublicSnapshot):CoverageResult & {coverageSummary:PortableCoverageSummary} {
  const keyword=request.keyword.trim().toLocaleLowerCase("zh-CN"),offset=request.offset??0,limit=request.limit??41;
  const companies=snapshot.companies.filter(c=>!keyword||c.companyName.toLocaleLowerCase("zh-CN").includes(keyword)||c.pinyin.toLocaleLowerCase("zh-CN").includes(keyword))
    .sort((a,b)=>a.pinyin.localeCompare(b.pinyin)||a.id.localeCompare(b.id)).map((c):CoverageCompany=>{
      const canonical=candidateCompanies.find(row=>row.id===c.id)!;
      const times=snapshot.sources.filter(s=>s.companyId===c.id).map(s=>s.lastSuccessAt).filter((v):v is string=>v!==null).sort();
      return {id:c.id,companyName:c.companyName,...sourceScopeNote(c.sourceIds,snapshot),officialWebsiteUrl:canonical.officialWebsiteUrl??null,
        officialCareersUrl:canonical.sources.find(s=>c.sourceIds.includes(s.id))?.officialEntryUrl??null,category:c.category,
        state:!c.required?"USER_AUTHORIZED_PHASE1_EXCLUSION":c.publishingSourceIds.length?"PUBLISHING":"VERIFYING",
        health:!c.required||c.health==="UNVERIFIED"?"NOT_APPLICABLE":c.health=== "HEALTHY"?"HEALTHY":"DEGRADED",
        lastSuccessAt:times.at(-1)??null};
    });
  return {companies:companies.slice(offset,offset+limit),offset,limit,hasMore:offset+limit<companies.length,coverageSummary:portableCoverageSummary(snapshot)};
}
