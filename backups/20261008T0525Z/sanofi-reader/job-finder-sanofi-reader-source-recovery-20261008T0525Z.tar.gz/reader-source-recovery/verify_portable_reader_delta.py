#!/usr/bin/env python3
"""Verify frozen reader source and patch in memory; never run project code.

Usage:
  python verify_portable_reader_delta.py --baseline baseline-source \
      --archive sanofi-exact-reviewed-reader-source.tar.gz \
      --patch sanofi-exact-reviewed-reader.patch

baseline-source holds only the five exact ordinary source preimages. Passing
does not certify a complete application or authorize deployment or DB access.
"""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tarfile

TAR_SHA256 = "10626ae31c39995147b6afc9a2d631ca6a3e9dcdf66b708ec60869ec8e03ffc6"
PATCH_SHA256 = "3bd829c979a3adece3ec4efaf5abf07317667318d6515d5b472e17220d76ac11"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def apply_exact(base, patch):
    lines = patch.decode("utf-8").splitlines(keepends=True)
    result = {}
    index = 0
    while index < len(lines):
        assert lines[index].startswith("--- ")
        old_path = lines[index][4:].strip()
        assert lines[index + 1].startswith("+++ b/")
        name = lines[index + 1][6:].strip()
        assert old_path in ("a/" + name, "/dev/null")
        assert name in base, "patch path outside manifest"
        original = base[name].decode("utf-8").splitlines(keepends=True)
        cursor = 0
        output = []
        index += 2
        while index < len(lines) and lines[index].startswith("@@ "):
            match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
            assert match
            old_start, old_count, new_start, new_count = [int(x) if x is not None else 1 for x in match.groups()]
            start = old_start - 1 if old_count else old_start
            assert start >= cursor
            output.extend(original[cursor:start])
            cursor = start
            assert len(output) == (new_start - 1 if new_count else new_start)
            consumed = produced = 0
            index += 1
            while index < len(lines) and not lines[index].startswith(("@@ ", "--- ")):
                line = lines[index]
                assert line[0] in " +-"
                if line[0] in " -":
                    assert cursor < len(original) and original[cursor] == line[1:], (name, cursor)
                    cursor += 1
                    consumed += 1
                if line[0] in " +":
                    output.append(line[1:])
                    produced += 1
                index += 1
            assert consumed == old_count and produced == new_count
        output.extend(original[cursor:])
        assert name not in result
        result[name] = "".join(output).encode("utf-8")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--baseline", required=True, type=Path)
    parser.add_argument("--archive", required=True, type=Path)
    parser.add_argument("--patch", required=True, type=Path)
    args = parser.parse_args()
    assert sha(args.archive.read_bytes()) == TAR_SHA256, "frozen archive mismatch"
    patch = args.patch.read_bytes()
    assert sha(patch) == PATCH_SHA256, "frozen patch mismatch"
    with tarfile.open(args.archive) as archive:
        members = archive.getmembers()
        assert len(members) == 7 and len({m.name for m in members}) == 7
        for m in members:
            p = PurePosixPath(m.name)
            assert m.isfile() and not p.is_absolute() and ".." not in p.parts
        content = {m.name: archive.extractfile(m).read() for m in members}
    manifest = json.loads(content["CANDIDATE_MANIFEST.json"])
    entries = manifest["files"]
    assert len(entries) == 6
    assert set(content) == {x["path"] for x in entries} | {"CANDIDATE_MANIFEST.json"}
    base = {}
    for entry in entries:
        name = entry["path"]
        local = args.baseline / name
        if entry["oldSha256"] is None:
            assert not local.exists(), "new file must be absent from preimage set"
            base[name] = b""
        else:
            assert local.is_file() and not local.is_symlink()
            base[name] = local.read_bytes()
            assert sha(base[name]) == entry["oldSha256"], "old source mismatch: " + name
        assert sha(content[name]) == entry["newSha256"]
        assert len(content[name]) == entry["bytes"]
    restored = apply_exact(base, patch)
    assert set(restored) == set(base)
    assert all(restored[name] == content[name] for name in restored)
    print(json.dumps({"status": "PASS", "sourceFiles": len(entries),
        "sourceBytes": sum(x["bytes"] for x in entries),
        "fiveExactPreimagesPlusOneNewFile": True,
        "patchReconstructsExactArchivedBytes": True,
        "wholeApplicationRecovery": "Requires the original role-specific baseline and dependencies"}, indent=2))


if __name__ == "__main__":
    main()
