/** Source-local guard for the unchanged C60 Sanofi A route. No acquisition or SQL. */
import { requiresAGradeOfficialTotalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/completenessCertificate.ts';
import { requiresBGradeTraversalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/traversalCertificate.ts';
import { getSourceQualityPolicy } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourceQualityAdmission.ts';
import { buildStagedSourceCrawlPlans, sourcePlanConfigSha256, type SourceCrawlPlan } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourcePlan.ts';
import { candidateCompanies } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/data/companyRegistry.ts';
export function assertSanofiAPlan(plan:SourceCrawlPlan | undefined):asserts plan is SourceCrawlPlan {
 if(!plan || plan.source.id!=='source-sanofi-china-social' || sourcePlanConfigSha256(plan)!=='106fb80ad4e6c953d41a2dd67156f42e1bc4416766c98912a60ad59722df97c3' || plan.adapterId!=='html-table' || plan.table?.sanofiNativePolicy!=='SANOFI_EN_CN_NATIVE_CHAIN_V1' || !requiresAGradeOfficialTotalCertificate(plan) || requiresBGradeTraversalCertificate(plan) || getSourceQualityPolicy(plan)!==null)throw Error('HOST_ORIGINAL_SANOFI_A_ROUTE_REQUIRED');
}
export function getSanofiAPlan():SourceCrawlPlan {
 const plan=buildStagedSourceCrawlPlans(candidateCompanies).find(p=>p.source.id==='source-sanofi-china-social');assertSanofiAPlan(plan);return plan;
}
