// functions.exec AsyncFunction body. Required parameter: sourceKey.
// Run once after the original source loader, before launch/review deadlines.
// This reads/pins local code only; it does not submit SQL or start a producer.
if(typeof sourceKey !== 'string' || sourceKey.length > 64 || sourceKey !== sourceKey.trim() || !/^(?:[a-z][a-z0-9]*|boehringer-ingelheim)$/.test(sourceKey))throw Error('OWNER_SOURCE_KEY');
const ns='proxyNode22:'+sourceKey+':';
const q=s=>"'"+String(s).replaceAll("'","'\\''")+"'";
const result=await tools.exec_command({cmd:'python3 - '+q('/workspace/scratch/5e9614251709/job-finder-sanofi-a-host-preparation-20261008T0343Z/owner-adaptations/sanofi-c60-r4-20261008T0343Z')+' '+q(sourceKey)+" <<'PY_OWNER_LOAD'\n"+
`from pathlib import Path
import hashlib,json,sys
p=Path(sys.argv[1]);source=sys.argv[2]
owner=(p/'publish-and-monitor-owner.js').read_bytes();manifest_bytes=(p/'baseline-manifest.json').read_bytes()
assert hashlib.sha256(owner).hexdigest()=='0373466f44366c0d64d61f193d96ece20f66b49047bf5e21ce0a6f8819811c52'
assert hashlib.sha256(manifest_bytes).hexdigest()=='9a51022a8a6715b92f16092d4e59bf8ce68c62f42e8419390d5a9926a638d887'
m=json.loads(manifest_bytes);root=Path(m['runtimeRoot'])/'hosts'/source/'host'
files={}
for name in ['host-helper-functions.js','host-stage-functions.js','runtime/continuous-relay-v3-durable-monitor.js','relay-files.mjs','runtime/review-packet-envelope.mts']:
 path=root/name;data=path.read_bytes();assert hashlib.sha256(data).hexdigest()==m['files'][str(path)]['sha256']
 if name in ['host-helper-functions.js','host-stage-functions.js','runtime/continuous-relay-v3-durable-monitor.js']:files[name]=data.decode()
print(json.dumps({'ownerCode':owner.decode(),'ownerSha256':'0373466f44366c0d64d61f193d96ece20f66b49047bf5e21ce0a6f8819811c52','hostRoot':str(root),'files':files}))
`+'PY_OWNER_LOAD',max_output_tokens:20000,yield_time_ms:1000});
if(result.exit_code!==0||result.session_id)throw Error('OWNER_PRELOAD_LOCAL_READ_FAILED');
const p=JSON.parse(result.output);
if(load(ns+'cloudPilotHostHelpers')!==p.files['host-helper-functions.js']||
 load(ns+'cloudPilotHostStages')!==p.files['host-stage-functions.js']||
 load(ns+'continuousPortableRelayCodeWithPoll')!==p.files['runtime/continuous-relay-v3-durable-monitor.js']||
 load(ns+'cloudPilotHostConfig')?.root!==p.hostRoot)throw Error('OWNER_PRELOAD_STORED_CODE_MISMATCH');
store(ns+'publishMonitorPrepared',{ownerCode:p.ownerCode,ownerSha256:p.ownerSha256,
 helperCode:p.files['host-helper-functions.js'],stageCode:p.files['host-stage-functions.js'],
 monitorCode:p.files['runtime/continuous-relay-v3-durable-monitor.js'],hostRoot:p.hostRoot});
text({status:'OWNER_CODE_PINNED_NO_LAUNCH',sourceKey,ownerSha256:p.ownerSha256});
