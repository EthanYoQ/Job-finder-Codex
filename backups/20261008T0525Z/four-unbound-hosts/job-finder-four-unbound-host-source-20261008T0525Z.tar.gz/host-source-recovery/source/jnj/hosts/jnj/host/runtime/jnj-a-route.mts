/** Source-local guard for the unchanged C60 Jnj A route. No acquisition or SQL. */
import { requiresAGradeOfficialTotalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/completenessCertificate.ts';
import { requiresBGradeTraversalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/traversalCertificate.ts';
import { getSourceQualityPolicy } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourceQualityAdmission.ts';
import { buildStagedSourceCrawlPlans, sourcePlanConfigSha256, type SourceCrawlPlan } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourcePlan.ts';
import { candidateCompanies } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/data/companyRegistry.ts';
export function assertJnjAPlan(plan:SourceCrawlPlan | undefined):asserts plan is SourceCrawlPlan {
 if(!plan || plan.source.id!=='source-johnson-innovative-medicine-social' || sourcePlanConfigSha256(plan)!=='80d9610e77965de2e15efba070735e77227c70efedb543d110bb259f75782cf3' || plan.company.id!=='company-johnson-innovative-medicine' || plan.source.companyId!=='company-johnson-innovative-medicine' || plan.executionAuthority!=='STAGED' || plan.adapterId!=='official-json' || plan.profileBoundSource?.kind!=='jnj-careers-china' || !requiresAGradeOfficialTotalCertificate(plan) || requiresBGradeTraversalCertificate(plan) || getSourceQualityPolicy(plan)!==null)throw Error('HOST_ORIGINAL_JNJ_A_ROUTE_REQUIRED');
}
export function getJnjAPlan():SourceCrawlPlan {
 const plan=buildStagedSourceCrawlPlans(candidateCompanies).find(p=>p.source.id==='source-johnson-innovative-medicine-social');assertJnjAPlan(plan);return plan;
}
