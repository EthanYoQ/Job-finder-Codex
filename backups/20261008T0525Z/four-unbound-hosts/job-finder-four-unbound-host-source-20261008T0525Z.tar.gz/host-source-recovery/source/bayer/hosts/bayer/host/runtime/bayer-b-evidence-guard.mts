/** Source-local restoration of the immutable B issuer's complete scope binding.
 * Receipt identity checks detect main-original reuse. They cannot authenticate a
 * fabricated timestamp: root-owned execution evidence remains a live gate. */
import {createHash} from 'node:crypto';
import {parseBGradeIndependentTraversalValidation} from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/traversalCertificate.ts';
import {OFFICIAL_JSON_RENDERED_TRAVERSAL_POLICIES} from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/officialJsonRenderedTraversalValidator.ts';
import {sourcePlanConfigSha256,type SourceCrawlPlan} from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourcePlan.ts';
import {assertBayerBPlan} from './bayer-b-route.mts';
const canonical=(v:readonly string[])=>[...new Set(v)].sort((a,b)=>Buffer.compare(Buffer.from(a),Buffer.from(b)));
const exact=(a:unknown,b:unknown)=>JSON.stringify(a)===JSON.stringify(b);
export function assertBayerBIndependentScope(value:unknown,plan:SourceCrawlPlan,outer?:{binding?:Record<string,unknown>;scope?:Record<string,unknown>;mainTraversal?:Record<string,unknown>;issuedAt?:unknown}){
 assertBayerBPlan(plan);
 const v=parseBGradeIndependentTraversalValidation(value),policy=OFFICIAL_JSON_RENDERED_TRAVERSAL_POLICIES['source-bayer-healthcare-social'];
 const surfaces=canonical([plan.source.surfaceId!]),channels=canonical(plan.expectedChannels!.map(c=>c.channelId)),config=sourcePlanConfigSha256(plan);
 if(v.schemaVersion!=='official-json-browser-network-traversal-v1'||v.sourceId!==plan.source.id||v.companyId!==plan.company.id||v.companyId!==plan.source.companyId||v.companyId!==policy.companyId||v.sourceConfigSha256!==config||!exact(v.surfaceIds,surfaces)||!exact(v.channelIds,channels))throw Error('HOST_B_INDEPENDENT_PLAN_SCOPE_BINDING');
 if(v.retrievalPath!==policy.retrievalPath||v.validatorImplementationId!==policy.validatorImplementationId||v.matchKeyKind!==policy.matchKeyKind||v.artifactLogicalKey!==policy.artifactLogicalKey)throw Error('HOST_B_INDEPENDENT_REGISTERED_POLICY_BINDING');
 if(outer&&(outer.binding?.sourceId!==v.sourceId||outer.binding?.sourceConfigSha256!==v.sourceConfigSha256||outer.scope?.sourceId!==v.sourceId||outer.scope?.companyId!==v.companyId||outer.scope?.recruitmentType!==plan.source.kind||outer.scope?.geography!=='MAINLAND_CHINA'||outer.scope?.businessUnit!=='ALL'||!exact(outer.scope?.surfaceIds,v.surfaceIds)||!exact(outer.scope?.channelIds,v.channelIds)||outer.mainTraversal?.retrievalPath!==policy.mainRetrievalPath||outer.mainTraversal?.matchKeyKind!==policy.matchKeyKind))throw Error('HOST_B_INDEPENDENT_OUTER_SCOPE_BINDING');
 const observed=Date.parse(v.observedAt),entry=v.pages[0]!.rawRows[0]!.rawPayload.entry as Record<string,any>;
 const entryAt=Date.parse(entry.capturedAt),now=Date.now(),issued=outer?Date.parse(String(outer.issuedAt)):now;
 if(!Number.isFinite(issued)||issued>now||entryAt>issued)throw Error('HOST_B_ORIGINAL_TIME_ORDER');
 let priorDom=observed;
 for(const page of v.pages){const dom=page.rawRows[0]!.rawPayload.domPage as Record<string,any>;const at=Date.parse(dom.capturedAt);if(!Number.isFinite(at)||at<priorDom||at>entryAt)throw Error('HOST_B_DOM_BEFORE_INDEPENDENT_HTTP_REQUIRED');priorDom=at;}
 let priorHttp=entryAt;
 for(const page of v.pages)for(const row of page.rawRows){const receipt=row.rawPayload.detailResponse as Record<string,any>;const at=Date.parse(receipt.capturedAt);if(!Number.isFinite(at)||at<priorHttp||at>issued||at-observed>3600000)throw Error('HOST_B_INDEPENDENT_HTTP_TIME_ORDER');priorHttp=at;}
 return v;
}
type Artifact=Record<string,any>;
const digest=(value:Uint8Array|string)=>createHash('sha256').update(value).digest('hex');
const url=(value:string)=>{const u=new URL(value);u.hash='';return u.href;};
function originalIdentity(a:Artifact):string|undefined{
 const locator=a.extractorLocator;
 let method:string,jobId:string|null=null;
 if(locator==='html:#init-data[value]')method='GET';
 else if(typeof locator==='string'&&locator.startsWith('moka-detail-v2|')){
  const m=/^moka-detail-v2\|request:jobId64=([A-Za-z0-9_-]+)\|request-contract-v2\|sha256:[a-f0-9]{64}$/.exec(locator);
  if(!m)throw Error('HOST_B_MAIN_DETAIL_REQUEST_IDENTITY');
  method='POST';jobId=Buffer.from(m[1]!,'base64url').toString('utf8');
  if(Buffer.from(jobId).toString('base64url')!==m[1])throw Error('HOST_B_MAIN_DETAIL_REQUEST_IDENTITY');
 }else return undefined;
 const hash=a.body!==undefined?digest(typeof a.body==='string'?a.body:Buffer.from(a.body)):a.sha256;
 if(!/^[a-f0-9]{64}$/.test(hash)||!Number.isFinite(Date.parse(a.capturedAt))||a.httpStatus!==200||(a.bodyRepresentation&&a.bodyRepresentation!=='EXACT'))throw Error('HOST_B_MAIN_ORIGINAL_RESPONSE_REQUIRED');
 return JSON.stringify([method,url(a.requestedUrl),url(a.finalUrl),jobId,a.httpStatus,a.capturedAt,hash]);
}
export function assertBayerBResponseSeparation(value:unknown,plan:SourceCrawlPlan,mainArtifacts:readonly Artifact[]){
 const v=assertBayerBIndependentScope(value,plan),main=new Set(mainArtifacts.map(originalIdentity).filter((x):x is string=>x!==undefined));
 if(main.size<2)throw Error('HOST_B_MAIN_ORIGINAL_RESPONSES_REQUIRED');
 let checked=0;
 for(const page of v.pages)for(const row of page.rawRows){
  const payload=row.rawPayload;
  for(const r of [payload.entry,payload.detailResponse])if(r){
   const receipt=r as Record<string,any>;
   const hash=digest(receipt.body);
   if(hash!==receipt.bodySha256)throw Error('HOST_B_INDEPENDENT_ORIGINAL_RESPONSE_HASH');
   const id=JSON.stringify([receipt.method,url(receipt.url),url(receipt.finalUrl),receipt.method==='POST'?receipt.requestBody?.jobId:null,receipt.status,receipt.capturedAt,hash]);
   if(main.has(id))throw Error('HOST_B_MAIN_RESPONSE_REUSED_AS_INDEPENDENT');
   checked++;
  }
 }
 return {checkedIndependentReceipts:checked,mainOriginalReceiptCount:main.size,identicalOriginalReceiptOverlap:false,liveExecutionProvenance:'ROOT_OWNED_EXECUTION_REVIEW_STILL_REQUIRED'};
}
/** Decode only the unchanged compiler's exact sqlRecords formats; never execute SQL. */
export function extractBayerMainArtifacts(sql:string,terminal:Record<string,any>):Artifact[]{
 const literal="E'(?:\\\\\\\\|''|[^'\\\\])*'";
 const blocks=[...sql.matchAll(new RegExp('jsonb_populate_recordset\\(NULL::public\\."EvidenceArtifact", ([\\s\\S]*?)\\);','g'))];
 if(!blocks.length)throw Error('HOST_B_MAIN_ARTIFACT_SQL_REQUIRED');
 const text=(s:string)=>s.slice(2,-1).replace(/\\\\/g,'\\').replace(/''/g,"'");
 const json=(s:string)=>JSON.parse(text(s));
 const rows:Artifact[]=[];
 for(const block of blocks){
  const expression=block[1]!;
  const direct=new RegExp('^('+literal+')::jsonb$').exec(expression);
  if(direct){const a=json(direct[1]!);if(!Array.isArray(a))throw Error('HOST_B_MAIN_ARTIFACT_SQL_RECORDS');rows.push(...a);continue;}
  const tuple=new RegExp('^\\(SELECT jsonb_agg\\(('+literal+')::jsonb \\|\\| jsonb_build_object\\(([\\s\\S]*?)\\) ORDER BY tuple.ordinality\\)\\n    FROM jsonb_array_elements\\(('+literal+')::jsonb\\) WITH ORDINALITY AS tuple\\(value, ordinality\\)\\)$').exec(expression);
  if(!tuple)throw Error('HOST_B_MAIN_ARTIFACT_SQL_FORMAT');
  const common=json(tuple[1]!),data=json(tuple[3]!);if(!common||typeof common!=='object'||Array.isArray(common)||!Array.isArray(data))throw Error('HOST_B_MAIN_ARTIFACT_SQL_RECORDS');
  const fields=[...tuple[2]!.matchAll(new RegExp('('+literal+'), tuple.value->([0-9]+)','g'))];
  if(fields.map(m=>m[0]).join(', ')!==tuple[2]!)throw Error('HOST_B_MAIN_ARTIFACT_SQL_FIELDS');
  for(const values of data){if(!Array.isArray(values))throw Error('HOST_B_MAIN_ARTIFACT_SQL_TUPLE');const record={...common};for(const f of fields){const key=text(f[1]!),index=Number(f[2]);if(key in record||index>=values.length)throw Error('HOST_B_MAIN_ARTIFACT_SQL_FIELD');Object.defineProperty(record,key,{value:values[index],enumerable:true});}rows.push(record);}
 }
 for(const a of rows)for(const [field,target]of Object.entries({releaseCandidateId:'releaseCandidateId',batchId:'batchId',sourceId:'sourceId',sourceResultId:'id'}))if(a[field]!==terminal[target])throw Error('HOST_B_MAIN_ARTIFACT_SQL_BINDING');
 return rows;
}
