// Local, non-executing parser for the frozen compiler's exact JSON declarations.
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { verifyNodeRuntimeProfile } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/scripts/verify-node-runtime-profile.ts';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { compileAtomicJsonDeclarations } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/db/atomicJsonDeclarations.ts';
import { unwrapJobProjectionSourceRow } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/db/jobProjectionDeltaCompiler.ts';
import { parseJobProjectionDeltaReceipt, hashProjectionJson } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/domain/jobProjectionDeltaReceipt.ts';
import { verifyBGradeTraversalCertificateReceipt } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/traversalCertificate.ts';
import { getBayerBPlan } from './bayer-b-route.mts';
import { assertBayerBIndependentScope,assertBayerBResponseSeparation,extractBayerMainArtifacts } from './bayer-b-evidence-guard.mts';
const sha = (value:string) => createHash('sha256').update(value).digest('hex');
export function decodeDeclarations(source:string) {
  let offset=0;const variables=new Map<string,unknown>();
  const requireText=(text:string)=>{if(!source.startsWith(text,offset))throw Error('HOST_JSON_DECLARATION_SYNTAX');offset+=text.length;};
  const literal=()=>{requireText("E'");let text='';while(offset<source.length){const c=source[offset++]!;if(c==='\\'){const n=source[offset++]!;if(n!=='\\')throw Error('HOST_JSON_ESCAPE');text+=n;}else if(c==="'"){if(source[offset]==="'"){offset++;text+="'";}else return text;}else text+=c;}throw Error('HOST_JSON_UNTERMINATED');};
  const expression=():unknown=>{
    if(source.startsWith("E'",offset)){const text=literal();requireText('::jsonb');return JSON.parse(text);}
    for(const kind of ['jsonb_build_array','jsonb_build_object'])if(source.startsWith(kind+'(',offset)){
      requireText(kind+'(');const values:unknown[]=[];
      while(source[offset]!==')'){if(values.length)requireText(',');values.push(kind==='jsonb_build_object'&&values.length%2===0?literal():expression());}
      requireText(')');if(kind==='jsonb_build_array')return values;
      if(values.length%2)throw Error('HOST_JSON_OBJECT_ARITY');const obj:Record<string,unknown>={};
      for(let i=0;i<values.length;i+=2)Object.defineProperty(obj,String(values[i]),{value:values[i+1],enumerable:true,writable:true,configurable:true});return obj;
    }
    if(source[offset]==='('){offset++;let result=expression();while(source.startsWith(' || ',offset)){offset+=4;const next=expression();if(Array.isArray(result)&&Array.isArray(next))result=[...result,...next];else if(result&&next&&typeof result==='object'&&typeof next==='object'&&!Array.isArray(result)&&!Array.isArray(next))result={...result,...next};else throw Error('HOST_JSON_CONCAT_TYPES');}requireText(')');return result;}
    const match=/^atomic_json_[0-9]+/.exec(source.slice(offset));if(!match||!variables.has(match[0]))throw Error('HOST_JSON_REFERENCE');offset+=match[0].length;return variables.get(match[0]);
  };
  while(offset<source.length){const match=/^(atomic_json_[0-9]+|source_result_data|expected_context_data) jsonb := /.exec(source.slice(offset));if(!match||variables.has(match[1]!))throw Error('HOST_JSON_DECLARATION');offset+=match[0].length;variables.set(match[1]!,expression());requireText(';');if(offset<source.length)requireText('\n');}
  const terminal=variables.get('source_result_data'),context=variables.get('expected_context_data');
  if(!terminal||!context||compileAtomicJsonDeclarations(terminal,context)!==source)throw Error('HOST_JSON_COMPILER_ROUNDTRIP');
  return {terminal:terminal as Record<string,any>,context:context as Record<string,any>};
}
export function inspectPacketSql(sql:string){
  if(sha(readFileSync(new URL('./bayer-b-evidence-guard.mts',import.meta.url),'utf8'))!=='15cfd5c7ffe736af4ce17f4cfc8ae9fc0030882fee5680684de7c97e50ed49d8')throw Error('HOST_BAYER_B_EVIDENCE_GUARD_PIN_MISMATCH');
  if(sha(readFileSync(new URL('./bayer-b-route.mts',import.meta.url),'utf8'))!=='eb10a93e23f78510c864a39e821bac2f28f7f559be481364cd87df0caaf3eb96')throw Error('HOST_BAYER_B_ROUTE_PIN_MISMATCH');
  const match=/^SET LOCAL statement_timeout = '120000ms';\nDO (\$atomic_[a-f0-9]{32}\$)\nDECLARE affected bigint; job_data jsonb; ([\s\S]*?) current_context jsonb; current_count bigint; current_hash text; aggregate_hash text;\nBEGIN\n([\s\S]*)\nEND;\n\1;$/.exec(sql);
  if(!match||match[2]!.includes(match[1]!)||match[3]!.includes(match[1]!))throw Error('HOST_ATOMIC_PACKET_SHAPE');
  const {terminal,context}=decodeDeclarations(match[2]!);
  const receipt=parseJobProjectionDeltaReceipt(terminal.completenessCertificate,terminal.completenessCertificateSha256);
  if(hashProjectionJson(receipt.legacyCertificate)!==receipt.legacyCertificateSha256)throw Error('HOST_DELTA_LEGACY_HASH');
  const legacy=unwrapJobProjectionSourceRow(terminal);
  const plan=getBayerBPlan();
  if(typeof legacy.completenessCertificateSha256!=='string')throw Error('HOST_B_CERTIFICATE_HASH_REQUIRED');
  // Use the compiler's actual main-observation commitment, never an inferred independent set.
  const observations=[...sql.matchAll(/jsonb_populate_recordset\(NULL::public\."CrawlObservation", (E'(?:\\\\|''|[^'\\])*')::jsonb\)/g)];
  if(observations.length!==1)throw Error('HOST_B_MAIN_OBSERVATION_REQUIRED');
  const observationRows=JSON.parse(observations[0]![1]!.slice(2,-1).replace(/\\\\/g,'\\').replace(/''/g,"'"));
  if(!Array.isArray(observationRows)||observationRows.length!==1)throw Error('HOST_B_MAIN_OBSERVATION_REQUIRED');
  const observation=observationRows[0];
  for(const [field,target]of Object.entries({sourceId:'sourceId',sourceResultId:'id',batchId:'batchId',releaseCandidateId:'releaseCandidateId',sourceConfigSha256:'sourceConfigHash'}))if(observation[field]!==terminal[target])throw Error('HOST_B_MAIN_OBSERVATION_BINDING');
  if(!/^[a-f0-9]{64}$/.test(observation.canonicalRawSha256)||observation.canonicalOutputSha256!==terminal.canonicalCurrentJobSetSha256||observation.rawCount!==terminal.rawCount||observation.dedupeOutputCount!==terminal.dedupeOutputCount||observation.observedFrom!==terminal.startedAt||observation.observedTo!==terminal.finishedAt)throw Error('HOST_B_MAIN_OBSERVATION_COMMITMENT');
  const bCertificate=legacy.completenessCertificate as Record<string,any>;
  assertBayerBIndependentScope(bCertificate.independentValidation,plan,bCertificate);
  const responseSeparation=assertBayerBResponseSeparation(bCertificate.independentValidation,plan,extractBayerMainArtifacts(sql,terminal));
  const bGradeReceipt=verifyBGradeTraversalCertificateReceipt({certificate:legacy.completenessCertificate,certificateSha256:legacy.completenessCertificateSha256,expected:{releaseCandidateId:terminal.releaseCandidateId,batchId:terminal.batchId,sourceResultId:terminal.id,sourceId:plan.source.id,companyId:plan.company.id,sourceConfigSha256:'df4b8294c45f3bcad0675d64b4211522f3265bae68a38c0825c3d99773f139e9',surfaceIds:[plan.source.surfaceId!],channelIds:plan.expectedChannels!.map(c=>c.channelId),canonicalJobSetSha256:terminal.canonicalCurrentJobSetSha256,canonicalRawEvidenceIdSetSha256:observation.canonicalRawSha256,adapterReconciliationSha256:terminal.adapterReconciliationSha256,collisionLedgerSha256:terminal.collisionLedgerSha256},now:new Date()});
  const certificate=legacy.completenessCertificate as {schemaVersion?:string;issuedAt?:string;validationPolicy?:{execution?:string;trigger?:string};mainTraversal?:{paginationTraceSha256?:string}};
  if(certificate.schemaVersion!=='b-grade-independent-traversal-v2'||certificate.validationPolicy?.execution!=='CURRENT_RUN'||certificate.validationPolicy?.trigger!=='INITIAL_QUALIFICATION'||certificate.issuedAt!==terminal.finishedAt||certificate.mainTraversal?.paginationTraceSha256!==observation.paginationTraceSha256)throw Error('HOST_B_CURRENT_CERTIFICATE_REQUIRED');
  if(terminal.sourceId!==plan.source.id || terminal.sourceConfigHash!=='df4b8294c45f3bcad0675d64b4211522f3265bae68a38c0825c3d99773f139e9')throw Error('HOST_BAYER_B_SOURCE_BINDING');
  return {terminal,context,legacyCertificate:legacy.completenessCertificate,bGradeReceipt,responseSeparation,mainObservation:observation,delta:{schemaVersion:receipt.schemaVersion,manifestSha256:receipt.manifestSha256,memberCount:receipt.members.length,observedAt:receipt.observedAt,verifiedAt:receipt.verifiedAt},sqlSha256:sha(sql),declarationMode:'FROZEN_COMPILER_SHARED_JSON_V1'};
}
export function inspectRequest(request:any){
  const {requestSha256,...body}=request;
  if(request.kind!=='PUBLISH'||sha(JSON.stringify(body))!==requestSha256||typeof request.payload?.sql!=='string')throw Error('HOST_PUBLICATION_REQUEST_HASH');
  const packet=inspectPacketSql(request.payload.sql);
  if(request.payload.projectId!=='yiopvxysxrtrnvqxwgbx')throw Error('HOST_PUBLICATION_PROJECT');
  return {...packet,requestId:request.requestId,requestSha256,validated:true};
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url)){
  await verifyNodeRuntimeProfile();
  const [requestPath,mode,...extra]=process.argv.slice(2);if(!requestPath||extra.length||mode&&mode!=='summary')throw Error('HOST_PACKET_REVIEW_ARGUMENTS');
  const out=inspectRequest(JSON.parse(readFileSync(requestPath,'utf8')));
  if(mode==='summary'){const {terminal,context,legacyCertificate,delta,...summary}=out;console.log(JSON.stringify(summary));}else console.log(JSON.stringify(out));
}
