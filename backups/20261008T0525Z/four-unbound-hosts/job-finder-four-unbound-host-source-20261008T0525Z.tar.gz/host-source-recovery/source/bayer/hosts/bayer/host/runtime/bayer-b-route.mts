/** Source-local guard for the unchanged C60 Bayer B route. No acquisition or SQL. */
import { requiresAGradeOfficialTotalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/completenessCertificate.ts';
import { requiresBGradeTraversalCertificate } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/traversalCertificate.ts';
import { getSourceQualityPolicy } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourceQualityAdmission.ts';
import { buildStagedSourceCrawlPlans, sourcePlanConfigSha256, type SourceCrawlPlan } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/crawler/sourcePlan.ts';
import { candidateCompanies } from '/workspace/scratch/5e9614251709/job-finder-c51-runtime-recovery-20261008T0201Z/producer/src/data/companyRegistry.ts';
export function assertBayerBPlan(plan:SourceCrawlPlan | undefined):asserts plan is SourceCrawlPlan {
 if(!plan || plan.source.id!=='source-bayer-healthcare-social' || sourcePlanConfigSha256(plan)!=='df4b8294c45f3bcad0675d64b4211522f3265bae68a38c0825c3d99773f139e9' || plan.adapterId!=='official-json' || plan.source.atsKind!=='MOKA' || plan.moka?.scopeExclusionProof!=='BAYER_MEDICAL_OPEN_REQUISITIONS_V1' || requiresAGradeOfficialTotalCertificate(plan) || !requiresBGradeTraversalCertificate(plan) || getSourceQualityPolicy(plan)!==null)throw Error('HOST_ORIGINAL_BAYER_B_ROUTE_REQUIRED');
}
export function getBayerBPlan():SourceCrawlPlan {
 const plan=buildStagedSourceCrawlPlans(candidateCompanies).find(p=>p.source.id==='source-bayer-healthcare-social');assertBayerBPlan(plan);return plan;
}
